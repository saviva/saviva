<?php
/**
 *
 * Displays gallery items belonging to specific gallery categories
 *
 * @package Austin
 * @subpackage Template
 */

get_template_part('loop', 'gallery');