
<?php
/**
 * @var $style
 * @var $class
 * @var $title
 * @var $subtitle
 * @var $button_url
 * @var $button_text
 * @var $pitch_text
 */


echo do_shortcode('[heading2 style="' . $style . '" class="' . $class . '" title="' . $title . '" pitch_text="' . $pitch_text . '" subtitle="' . $subtitle . '" button_url="' . $button_url . '" button_text="' . $button_text . '" ]');

