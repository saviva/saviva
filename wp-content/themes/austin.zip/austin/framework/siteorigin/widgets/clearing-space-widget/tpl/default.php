<?php
/**
 * @var $height
 */


echo do_shortcode('[clearing_space height="' . $height . '" ]');