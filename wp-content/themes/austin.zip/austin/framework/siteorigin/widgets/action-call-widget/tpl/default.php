<?php
/**
 * @var $text
 * @var $button_url
 * @var $button_color
 * @var $button_text
 */


echo do_shortcode('[action_call text="' . $text . '" button_url="' . $button_url . '" button_color="' . $button_color . '" button_text="' . $button_text . '" ]');