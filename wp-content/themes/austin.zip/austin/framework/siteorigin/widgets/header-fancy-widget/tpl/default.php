<?php
/**
 * @var $class
 * @var $style
 * @var $title
 */


echo do_shortcode('[header_fancy class="' . $class . '" style="' . $style . '" title="' . $title . '" ]');