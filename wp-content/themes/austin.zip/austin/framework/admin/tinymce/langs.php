<script type="text/javascript">

	tinyMCE.addI18n({
		en_US:{
			shortcodepanel:{
				desc : 'Add Shortcode'
			}
		en:{
			shortcodepanel:{
				desc : 'Add Shortcode'
			}
		}
	});

</script>